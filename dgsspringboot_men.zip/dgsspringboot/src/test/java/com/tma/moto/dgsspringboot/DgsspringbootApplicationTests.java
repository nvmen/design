package com.tma.moto.dgsspringboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DgsspringbootApplicationTests {

	@Test
	void contextLoads() {
	}

}
