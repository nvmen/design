package com.human.testing.subgragh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SubgraghApplication {

	public static void main(String[] args) {
		SpringApplication.run(SubgraghApplication.class, args);
	}

}
