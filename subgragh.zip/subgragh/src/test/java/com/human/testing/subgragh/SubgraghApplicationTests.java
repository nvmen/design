package com.human.testing.subgragh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SubgraghApplicationTests {

	@Test
	void contextLoads() {
	}

}
