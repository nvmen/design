import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-guarded',
  templateUrl: './guarded.component.html',
  styleUrls: ['./guarded.component.css']
})
export class GuardedComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
